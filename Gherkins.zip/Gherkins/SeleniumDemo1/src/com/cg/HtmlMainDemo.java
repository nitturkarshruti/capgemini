package com.cg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;

public class HtmlMainDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Test website using HTML with out opening the browser window
		//required jars are:
		// htmljunit-driver-2.35.1.jar
		//selenium-server-standalone-2.48.2.jar
		HtmlUnitDriver d=new HtmlUnitDriver();
		d.get("file:///C:/html-pages/WorkingWithForms.html");
		
		System.out.println("Title on the page is: "+d.getTitle());
		
	}

}
