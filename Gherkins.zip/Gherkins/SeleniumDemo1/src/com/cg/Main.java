package com.cg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\shruthi789\\chromedriver.exe");
		ChromeDriver d=new ChromeDriver();
		
		WebDriver driver= new ChromeDriver();
		driver.get("file:///C:/html-pages/WorkingWithForms.html");
		
		//inserting elements directly into the form
		WebElement element = driver.findElement(By.name("txtUName"));
		element.sendKeys("shruti");
		
		
		element = driver.findElement(By.name("txtPwd"));
		element.sendKeys("shruti");
		
		
		element = driver.findElement(By.id("txtConfPassword"));
		element.sendKeys("shruti");
		
		
		element = driver.findElement(By.name("txtFN"));
		element.sendKeys("shruti");
		
		
		element = driver.findElement(By.name("txtLN"));
		element.sendKeys("nitturkar");
		
		element = driver.findElement(By.id("rbFemale"));
		element.click();
		
		element = driver.findElement(By.name("DtOB"));
		element.sendKeys("08-31-1996");
		
		element = driver.findElement(By.name("Email"));
		element.sendKeys("shruti@gmail.com");
		
		element = driver.findElement(By.name("Address"));
		element.sendKeys("Hyderabad");
		
		element = driver.findElement(By.name("City"));
		element.sendKeys("Pune");
		
		element = driver.findElement(By.name("Phone"));
		element.sendKeys("9857412036");
		
		//element = driver.findElement(By.name("chkHobbies"));
		//element.sendKeys("music");
		
		

d.close();
	}

}
