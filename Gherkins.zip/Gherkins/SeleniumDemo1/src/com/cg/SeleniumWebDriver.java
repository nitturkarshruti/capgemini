package com.cg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SeleniumWebDriver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\shruthi789\\chromedriver.exe");
		//create a new instance of chrome driver
		WebDriver driver= new ChromeDriver();
		//Used to visit the google homepage
		driver.get("http://www.google.com");
		//find the text input element by its name
		WebElement element = driver.findElement(By.name("q"));
		//enter something to search for
		element.sendKeys("cheese!");
		//submitting the web form. Webdriver will find the form from the element 
		element.submit();
		//check the title of the page
		System.out.println("Page title is: "+driver.getTitle());
		//close the browser
		driver.quit();
	}

}
