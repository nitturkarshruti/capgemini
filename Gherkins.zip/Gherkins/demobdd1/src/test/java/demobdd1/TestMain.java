package demobdd1;

import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.CucumberOptions;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;

//Run with Cucumber Test Runner
@RunWith(Cucumber.class)
//dryRun:true- To validate steps and Feature file
//dryRun:false- to validate and execute test cases 
//features: The package or directory containing all Feature files
//monochrome:true- Disable extra formatting characters
//monochrome:false- Enable extra formatting(for Linux only, do not use on Windows)
@CucumberOptions(dryRun=false,features="classpath:/features",monochrome=true)
public class TestMain {
}
