package com.cg;

import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\shruthi789\\chromedriver.exe");
		ChromeDriver d=new ChromeDriver();
		
		d.get("file:///C:/html-pages/PopupWin.html");
		String parent=d.getWindowHandle().toString();
		System.out.println("Parent window: "+parent);
		//click on "open" button
		d.findElement(By.name("Open")).click();
	try {
		Thread.sleep(10000);
	}catch(InterruptedException ex) {}
		System.out.println("Parent window: "+parent);
		
		Set<String> children=d.getWindowHandles();
		System.out.println("The number of child windows are: "+children.size());
		
		for(String childWin:children) {
			if(childWin.equals(parent)) {
				continue;
			}
			System.out.println("Child window: "+childWin);
			d.switchTo().window(childWin.toString());
			System.out.println(d.getTitle());
		}
		d.switchTo().window(parent);
		
d.close();
	}

}
