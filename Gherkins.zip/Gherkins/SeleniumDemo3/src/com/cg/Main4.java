package com.cg;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Main4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\shruthi789\\chromedriver.exe");
		ChromeDriver d=new ChromeDriver();
		
		d.get("file:///C:/html-pages/WorkingWithForms.html");
		
		String script="return document.forms[0].elements.length";
		String count = d.executeScript(script).toString();
		System.out.println("Elements found: "+count);
		
		
		d.close();
	}

}
