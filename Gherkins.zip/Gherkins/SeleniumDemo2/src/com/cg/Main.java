package com.cg;

import org.openqa.selenium.chrome.ChromeDriver;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "C:\\shruthi789\\chromedriver.exe");
		ChromeDriver d=new ChromeDriver();
		d.get("https://duckduckgo.com");
		String title=d.getTitle();  //retrieves the title from the page that we visited
		System.out.println("Title is: "+title);
		try
		{
			Thread.sleep(10000);
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
d.close();
	}

}
