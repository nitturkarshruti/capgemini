package com.cg;

public class Calculator {
	
	public double doSum(int x,int y) {
		return x+y;
	}
	public double doSub(int x,int y) {
		return x-y;
	}

	public double doMul(int x,int y) {
		return x*y;
	}
	public double doDiv(int x,int y) {
		return x/y;
	}
	}
