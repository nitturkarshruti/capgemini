package com.cg;

import static org.junit.Assert.*;

import org.junit.Test;

public class CalculatorTest {
	
	//define Object under Test
	Calculator cal = new Calculator();

	@Test
	public void testDoSum() {
		double ans = cal.doSum(15, 20);
		assertEquals(35, ans,0.01D);
	}

	@Test
	public void testDoSub() {
		double ans = cal.doSub(35, 20);
		assertEquals(15, ans,0.01D);
	}

	@Test
	public void testDoMul() {
		double ans = cal.doMul(4, 3);
		assertEquals(12, ans,0.01D);
	}

	@Test
	public void testDoDiv() {
		double ans = cal.doDiv(25, 5);
		assertEquals(5, ans,0.01D);
	}

}
