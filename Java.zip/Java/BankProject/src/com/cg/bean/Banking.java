package com.cg.bean;

public class Banking {
	int accno;
	String custname;
	double balance;
	public Banking(int accno, String custname,double balance) {
		// TODO Auto-generated constructor stub
		super();
		this.accno = accno;
		this.custname = custname;
		this.balance = balance;
	}
	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}
	public String getCustname() {
		return custname;
	}
	public void setCustname(String custname) {
		this.custname = custname;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
public void printDetails()
{
	System.out.println("Account number:"+accno+" Customer name:"+custname+"balance:"+balance);
}
public double withdraw(double amount)
{

	double rembal;
	rembal=this.balance-amount;
return rembal;
}
public double deposit(double amount)
{
	
	double newbal;
	newbal=this.balance+amount;
	return newbal;
	}}
