package com.cg.ui;

import com.cg.bean.Banking;

public class BankDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Banking b1=new Banking(100,"abc",5000);
		b1.printDetails();
		double n= b1.withdraw(1000);
		System.out.println("withdraw:"+n);
		double d= b1.deposit(1000);
		System.out.println("Deposit:"+d);

	}

}
