package cg;
import java.sql.*;   //step1:Import packages
import java.util.*;
//SCROLLABLE AND UPDATABLE RESULTSET
public class TestConnect4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver()); //2nd way to load driver
			
		String url="jdbc:oracle:thin:@10.219.34.3:1521:orcl";
		String user="trg510";
		String pass="training510";
		
		Connection con=DriverManager.getConnection(url,user,pass); //step3: Establish connection, throws SQLException
		System.out.println("connected");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter department ID:");
		int d=sc.nextInt();
		
		String sqlQuery="select did,dname,location from dept where did=?"; //query where did is inserted dynamically, ? makes query dynamic
		PreparedStatement st=con.prepareStatement(sqlQuery,ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE); //to run the dynamic query
		st.setInt(1, d);  //set the values to question marks
	
		ResultSet rs=st.executeQuery(); 
		
		if(rs.next()) //if record exist then retrieve it
		{
			int d_id=rs.getInt("did"); //to get the did from dept
			if(d_id==70) //as did=70 is not present in table, the row is not updated. try with 40 or 50
			{
				rs.updateString("dname", "Admin");
				rs.updateString(3, "Chennai");
				rs.updateRow();
			}
			String d_name=rs.getString("dname"); //to get dname column from dept
			String loc=rs.getString(3); //to get the 3rd column from dept
			System.out.println("Dept id:"+d_id+" ,Name:"+d_name+" ,loc:"+loc);
			System.out.println("--------");	
		}
		con.close(); //step6:closing resources
	}
	catch(SQLException e)
		{
		System.out.println(e.getMessage()+" "+e.getErrorCode()+" "+e.getSQLState()); //SQLException methods
		e.printStackTrace();
		}}
}
