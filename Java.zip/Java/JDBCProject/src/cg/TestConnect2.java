package cg;
import java.sql.*;   //step1:Import packages
//GIVES THE RECORDS IN REVERSE ORDER
public class TestConnect2 {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver"); //step2:load the driver, classNotFoundException is throwed, surround in try-catch.
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String url="jdbc:oracle:thin:@10.219.34.3:1521:orcl";
		String user="trg510";
		String pass="training510";
		
		Connection con=DriverManager.getConnection(url,user,pass); //step3: Establish connection, throws SQLException
		System.out.println("connected");
		
		Statement st=con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY); //Step4: Create JDBC statements,used to pass SQL queries
		//1st parameter retrieves the scrollable table and the changes made to table by other user should not be displayed as result
		ResultSet rs=st.executeQuery("select * from dept"); //step5: executing sql statements
		rs.afterLast(); //moves the cursor after last record
		while(rs.previous()) //if record exist then retrieve it
		{
			int d_id=rs.getInt("did"); //to get the did from dept
			String d_name=rs.getString("dname"); //to get dname column from dept
			String loc=rs.getString(3); //to get the 3rd column from dept
			System.out.println("Dept id:"+d_id+" ,Name:"+d_name+" ,loc:"+loc);
			System.out.println("--------");
		}
		con.close(); //step6:closing resources
	}
}
