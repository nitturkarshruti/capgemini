package cg;
import java.sql.*;   //step1:Import packages
import java.util.*;
//DELETE QUERY
public class TestConnect6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			//DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver()); //java8 loads drives automatically hence commented
			
		String url="jdbc:oracle:thin:@10.219.34.3:1521:orcl";
		String user="trg510";
		String pass="training510";
		
		Connection con=DriverManager.getConnection(url,user,pass); //step3: Establish connection, throws SQLException
		System.out.println("connected");
		con.setAutoCommit(false); //tells oracle not to commit after any insert,update,delete immediately unless said explicitly
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter department ID:");
		int d=sc.nextInt();
		
		String sqlQuery="delete from dept where did=?"; 
		PreparedStatement st=con.prepareStatement(sqlQuery); //to run the dynamic query
		//values are passed as per the update statement
		st.setInt(1, d);
		  //set the values to question marks
		//st.setString(2, dn);
		//st.setString(3, loc);
	int deletedRec=st.executeUpdate();
	System.out.println("Updated records "+deletedRec);
		
		con.commit();
		con.close(); //step6:closing resources
	}
	catch(SQLException e)
		{
		System.out.println(e.getMessage()+" "+e.getErrorCode()+" "+e.getSQLState()); //SQLException methods
		e.printStackTrace();
		}}
}
