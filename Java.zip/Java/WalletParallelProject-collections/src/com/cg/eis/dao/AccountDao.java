package com.cg.eis.dao;

import java.util.Map;
import com.cg.eis.bean.Account;

	public interface AccountDao {

		public boolean createAccount(Account ac);
		public Map<Long,Account> getAllAccount();
		public Account getAccountByMobile(long mobileNo);
		public boolean transferMoney(Account a1,Account a2);
		public boolean updateAccount(Account ac);
		public boolean deleteAccount(long mobile);
		public void withDraw(long myAc, double amt);
		
		}


