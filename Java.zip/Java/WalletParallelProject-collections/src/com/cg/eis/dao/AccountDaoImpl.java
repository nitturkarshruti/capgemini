package com.cg.eis.dao;

import java.sql.SQLException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import com.cg.eis.bean.Account;


	public class AccountDaoImpl implements AccountDao{

 //Wallet Database
		Map<Long,Account> walletAccounts = new ConcurrentHashMap<>();
 

 //Inserting new account into database.

 	@Override
   public boolean createAccount(Account ac) {
 		walletAccounts.put(ac.getMobileNo(), ac);
 		Account ac1 = walletAccounts.get(ac.getMobileNo());
 		if(ac1!=null)
 			return true;
 		else
 			return false;
 	}

 //Method to retrieve account number by mobile number from database

 	@Override
 	public Account getAccountByMobile(long mobileNo) {
 		// TODO Auto-generated method stub
 		Account ac2 = walletAccounts.get(mobileNo);
 		if(ac2!=null)
 			return ac2;
 		else
 			return null;
 	}

 //Retrieving all the Accounts Stores in Database.
 	@Override
 	public Map<Long, Account> getAllAccount() {
 		// TODO Auto-generated method stub
 		return walletAccounts;
 	}

 	@Override
 	public boolean transferMoney(Account ac1, Account ac2) {
 		walletAccounts.put(ac1.getMobileNo(), ac1);
 		Account a1 = walletAccounts.get(ac1.getMobileNo());
 		walletAccounts.put(ac2.getMobileNo(), ac2);
 		Account a2 = walletAccounts.get(ac2.getMobileNo());
 		if(a1!=null && a2!=null)
 			return true;
 		else
 			return false;
 	}

 	
 	@Override
 	  public boolean updateAccount(Account ac)
 	  {
 	   walletAccounts.put(ac.getMobileNo(), ac);
 	   Account ac1 = walletAccounts.get(ac.getMobileNo());
 	   if(ac1!=null)
 	     return true;
 	   else
 	   return false;
 	  }

 	@Override
 	public boolean deleteAccount(long mobile) {
 		// TODO Auto-generated method stub
 		Account bd =walletAccounts.remove(mobile);
 		if(bd.getMobileNo()==mobile)
 			return true;
 		else
 			return false;
 	}

 	@Override
 	public void withDraw(long myAc, double amt) {
 		// TODO Auto-generated method stub
 		Account bd = walletAccounts.get(myAc);
 		if(bd==null)
 		{
 			System.out.println("No Record Found.");
 			System.exit(0);
 		}
 		else
 		{	
 			double balance = bd.getBalance();
 			balance -= amt;
 			bd.setBalance(balance);
 			walletAccounts.put(myAc, bd);
 			System.out.println("Please Collect Your Cash.....!");
 			System.out.println("The balance after withdraw is: "+bd.getBalance());
 		}
 	}
}


