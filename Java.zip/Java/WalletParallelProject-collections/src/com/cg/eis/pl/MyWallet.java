package com.cg.eis.pl;

import com.cg.eis.service.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;
import com.cg.eis.bean.*;

public class MyWallet {

	public static void main(String[] args) throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		WalletService service = new WalletServiceImpl();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("======Banking application======");
		System.out.println("Enter no of accounts you would want to access");
		int a_no = Integer.parseInt(br.readLine());
		for (int i = 1; i <= a_no; i++) {
			System.out.println("Enter Details of Account Holder : " + i);
			System.out.println("Enter Account No : ");
			int accno = Integer.parseInt(br.readLine());
			System.out.println("Enter Account Holder Name : ");
			String cusName = br.readLine();
			System.out.println("Enter Mobile Number : ");
			boolean b = false;
			long mob = 0;
			do {
				String mobile = br.readLine();
				if (service.validateMobile(mobile)) {
					mob = Long.parseLong(mobile);
					b = true;
				} else
					System.out.println("Re-Enter Correct Mobile Number : ");
			} while (b != true);
			System.out.println("Enter Account Balance : ");
			Double bal = Double.parseDouble(br.readLine());
			Account a1 = new Account(accno, cusName, mob, bal);
			boolean added = service.createAccount(a1);
			System.out.println("Account added : " + added);
		}

		System.out.println("1.Diplay All Accounts\n2.Update an Account\n3.Delete an Account"
				+ "\n4.Transfer Money\n5.Deposit Money\n6.Get Account using mobile\n7.Withdraw\n8.exit");
		int ch = Integer.parseInt(br.readLine());
		int i = 0;
		do {
			i++;
			switch (ch) {
			case 1:
				Map<Long, Account> allAc = service.getAllAccount();
				System.out.println(allAc);
				break;

			case 2:
				System.out.println("Please Enter the Mobile Number to update data in your account.");
				String mob = br.readLine();
				if (service.validateMobile(mob)) {
					long mobil = Long.parseLong(mob);
					Account ac3 = service.getAccountByMobile(mobil);
					System.out.println("You can update your name only in the database. ");
					System.out.println("Press 0 to proceed for updation else 1 to go to main menu.");
					int op = Integer.parseInt(br.readLine());
					if (op == 0) {
						System.out.println("Please enter your name to update the record.");
						String name = br.readLine();
						ac3.setCustomerName(name);
						System.out.println("Congratulations..Your name has been updated..");
						System.out.println(service.getAccountByMobile(mobil));
					} else
						break;
				} else {
					System.out.println("Please check the mobile number you have entered..");
				}
				break;

			case 3:
				System.out.println("Enter Mobile number to delete the Account :");
				long mob2 = Long.parseLong(br.readLine());
				boolean res = service.deleteAccount(mob2);
				System.out.println("Delete Successful " + res);
				break;

			case 4:
				System.out.println("Enter Money to Transfer : ");
				double amount = Double.parseDouble(br.readLine());
				System.out.println("Enter Sender Mobile Number : ");
				long mono1 = Long.parseLong(br.readLine());
				System.out.println("Enter Receiver Mobile NUmber : ");
				long mono2 = Long.parseLong(br.readLine());
				Account a1 = service.getAccountByMobile(mono1);
				Account a2 = service.getAccountByMobile(mono2);
				boolean trans = service.transferMoney(amount, a1, a2);
				System.out.println(trans + " Transfer");
				break;
			case 5:
				System.out.println("Enter Money to add");
				double amt = Double.parseDouble(br.readLine());
				String m1 = br.readLine();
				System.out.println("Enter Mobile number to add Money");
				long mono = Long.parseLong(m1);
				Account ob1 = service.getAccountByMobile(mono);
				boolean res1 = service.addMoney(amt, ob1);
				System.out.println(res1);
				break;
			case 6:
				System.out.println("Enter Mobile Number to retrieve Account");
				long mob1 = Long.parseLong(br.readLine());
				System.out.println(mob1);
				Account myAc = service.getAccountByMobile(mob1);
				System.out.println(myAc);
				break;

			case 7:
				System.out.println("Enter money to Withdraw");
				double amt1 = Long.parseLong(br.readLine());
				System.out.println("Enter mobileno to withdraw money from : ");
				mob1 = Long.parseLong(br.readLine());
				service.withDraw(mob1, amt1);
				break;
				
			case 8:
				 System.out.println("****Thank you*****");
			      System.exit(0);

			default:
				System.out.println("Choose Valid Option : ");
				break;
			}

			System.out.println(
					"1.Diplay All Accounts\n"
					+ "2.Update an Account\n"
					+ "3.Delete an Account\n"
					+ "4.Transfer Money\n"
					+ "5.Add Money\n"
					+ "6.Get Account using mobile\n"
					+ "7.Withdraw"
					+ "8.exit");
			ch = Integer.parseInt(br.readLine());
		} while (ch != 9);
	}
}