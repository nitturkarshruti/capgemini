package com.cg.eis.pl;
import com.cg.eis.service.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;
import com.cg.eis.bean.*;

public class MyWallet {
	
 public static void main(String[] args) throws IOException {
 // TODO Auto-generated method stub
	 WalletService service = new WalletServiceImpl();
	 BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	 System.out.println("======Banking application======");
	 System.out.println("Enter no of accounts you want to add");
	 int a_no=Integer.parseInt(br.readLine());
	 for(int i=1;i<=a_no;i++)
	 	{
		 System.out.println("Enter Details of Account Holder : "+i);
		 //System.out.println("Enter Account No : ");
		 int accno = (int)((Math.random())*10000);
		 //System.out.println(accno);
		 System.out.println("Enter Account Holder Name : ");
		 String cusName = br.readLine();

		 System.out.println("Enter Mobile Number : ");
		 
		 boolean b=false;
		 long mob = 0;
		 
		 do {
			 String mobile = br.readLine();
			 if(service.validateMobile(mobile))
			 	{
				 mob= Long.parseLong(mobile);
				 b=true;
			 	}

			 else
				 System.out.println("Re-Enter Correct Mobile Number : ");
		 	}while(b!=true);
		 
		 System.out.println("Enter Account Balance : ");
		 Double bal = Double.parseDouble(br.readLine());
		 Account a1 = new Account(accno,cusName,mob,bal);
		 boolean added = service.createAccount(a1);
		 System.out.println("Account added : "+added);
	 	}

	 	System.out.println("1.Diplay All Accounts\n2.Update an Account\t3.Delete an Account"+
	 			"\n4.Transfer Money\t5.Add Money\t6.Get Account using mobile");
	 	int ch = Integer.parseInt(br.readLine());
	 	int i=0;
	 	do {
	 		i++;
	 		switch(ch)
	 		{
	 		case 1 :
	 			service.getAllAccount();
	 			break;
   
	 		case 2 :  
	 				System.out.println("Enter mobile to get update account");
	 				String mobUp=br.readLine();
	 				if(service.validateMobile(mobUp))
	 					{
	 					long mob0 = Long.parseLong(mobUp);
	 					Account ac5=service.getAccountByMobile(mob0);
	 					System.out.println(ac5);
	 					System.out.println("Only Name can be Updated,..If You want to Continue PRESS 1 else PRESS 0 to exit.");						int op=Integer.parseInt(br.readLine());
	 					if(op==1)
	 						{
	 							System.out.println("Enter Name");
	 							String name=br.readLine();
	 							ac5.setCustomerName(name);
	 							boolean stat = service.updateAccountDetails(ac5);
	 							if(stat==true)
	 								{
	 									System.out.println("Your Account has been updated : \n"+ac5);
	 								}
	 						}
	 				 }
	 				 else
	 					{
	 					 	System.out.println("Please Check the given Mobile Number.");
	 						}
	 					break; 
	 				 
	 		case 3 :
	 			System.out.println("Enter Mobile number to delete the Account :");
	 			long mob2 = Long.parseLong(br.readLine());
	 			boolean res = service.deleteAccount(mob2);
	 			System.out.println("Deleted Successfully "+res);
	 			break;	

	 		case 4 :
	 			System.out.println("Enter Money to Transfer : ");
	 			double amount = Double.parseDouble(br.readLine());
	 			System.out.println("Enter Sender Mobile Number : ");
	 			long mono1=Long.parseLong(br.readLine());
	 			System.out.println("Enter Receiver Mobile NUmber : ");
	 			long mono2=Long.parseLong(br.readLine());
	 			Account a1=service.getAccountByMobile(mono1);
	 			Account a2=service.getAccountByMobile(mono2);
	 			boolean trans = service.transferMoney(amount, a1, a2);
	 			System.out.println(trans+" Transfer");
	 			break;
	 			
	 		case 5 :
	 			System.out.println("Enter Money to add");
	 			double amt = Double.parseDouble(br.readLine());
	 			System.out.println("Enter Mobile number to add Money");
	 			long mono=Long.parseLong(br.readLine());
	 			Account ob1=service.getAccountByMobile(mono);
	 			boolean res1 = service.addMoney(amt, ob1);
	 			System.out.println(res1);
	 			break;

	 		case 6 :
	 			System.out.println("Enter Mobile Number to retrieve Account");
	 			long mob1 = Long.parseLong(br.readLine());
	 			System.out.println(mob1);
	 			Account myAc = service.getAccountByMobile(mob1);
	 			System.out.println(myAc);
	 			break;
	 			
	 		case 7:
	 			 System.out.println("****Thank you*****");
	 		      System.exit(0);

	 		default :
	 			System.out.println("Choose Valid Option : ");
	 			break;
	 		}

	 		System.out.println("1.Diplay All Accounts\n"
	 					+ "2.Update an Account\n"
	 					+ "3.Delete an Account\n"
	 					+ "4.Transfer Money\n"
	 					+ "5.Add Money\n"
	 					+ "6.Get Account using mobile\n"
	 					+ "7.Exit");
	 		ch = Integer.parseInt(br.readLine());
	 		if(ch==7)
	 			System.out.println("Exited");
	 	}while(ch!=7);
 	}
}

