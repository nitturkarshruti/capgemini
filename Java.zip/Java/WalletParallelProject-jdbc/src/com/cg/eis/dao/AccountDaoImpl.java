package com.cg.eis.dao;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import com.cg.eis.bean.Account;
import java.sql.*;

public class AccountDaoImpl implements AccountDao {
	Connection con;
	PreparedStatement pst;
	Statement sst;

	// Wallet Account Database
	Map<Long, Account> walletAccounts = new ConcurrentHashMap<>();

	// establishes the connection
	private void makeConnection() {
		try {
			String url = "jdbc:oracle:thin:@10.219.34.3:1521:orcl";
			String user = "trg510";
			String pass = "training510";
			con = DriverManager.getConnection(url, user, pass);
			System.out.println("Connected");
		} catch (SQLException e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	// releases the connection
	private void releaseConnection() {
		try {
			if (con != null)
				con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	// insert new account into database.

	@Override
	public boolean createAccount(Account ac) {
		boolean created = false;
		walletAccounts.put(ac.getMobileNo(), ac);
		Account ac1 = walletAccounts.get(ac.getMobileNo());
		if (ac1 != null) {
			try {
				makeConnection();
				pst = con.prepareStatement("insert into Accounts values(?,?,?,?)");
				pst.setInt(1, ac.getAccountNo());
				pst.setString(2, ac.getCustomerName());
				pst.setLong(3, ac.getMobileNo());
				pst.setDouble(4, ac.getBalance());
				int insert = pst.executeUpdate();

				System.out.println("Inserted into Database " + insert);
				created = true;
				releaseConnection();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				try {
					con.rollback();
					releaseConnection();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				e.printStackTrace();
				created = false;
				e.printStackTrace();
			}
			return true;
		} else
			return false;
	}

	// retrieve account number by mobile number from database
	@Override
	public Account getAccountByMobile(long mobileNo) {
		// TODO Auto-generated method stub
		Account a1 = null;
		int acno = 0;
		String cname = "";
		long mobile = 0;
		double balance = 0.0;
		boolean created = false;

		try {
			makeConnection();
			pst = con.prepareStatement("select * from Accounts where mobileno = ?");
			pst.setLong(1, mobileNo);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				acno = rs.getInt(1);
				cname = rs.getString(2);
				mobile = rs.getLong(3);
				balance = rs.getDouble(4);
			}
			a1 = new Account(acno, cname, mobile, balance);
			releaseConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			try {
				con.rollback();
				releaseConnection();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
			created = false;
			e.printStackTrace();
		}
		return a1;
	}

	// Retrieving all the Accounts Stores in Database.

	@Override
	public boolean getAllAccount() throws SQLException {
		// TODO Auto-generated method stub
		boolean deleted = false;
		makeConnection();
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("select * from Accounts");
		while (rs.next()) {
			System.out.println("accno : " + rs.getInt("acno"));
			System.out.println("cname : " + rs.getString("cname"));
			System.out.println("mobile : " + rs.getLong("mobileno"));
			System.out.println("balance : " + rs.getDouble("balance"));
			System.out.println("===================================");
		}
		releaseConnection();
		return true;
	}

	@Override
	public boolean updateAccount(Account ac) {
		// TODO Auto-generated method stub
		boolean transfered = false;
		try {
			makeConnection();
			con.setAutoCommit(false);
			pst = con.prepareStatement("update accounts set balance =? where acno=?");
			pst.setDouble(1, ac.getBalance());
			pst.setInt(2, ac.getAccountNo());
			int u1 = pst.executeUpdate();
			System.out.println("Updated account in database." + u1);

			walletAccounts.put(ac.getMobileNo(), ac);
			transfered = true;
			con.commit();
			releaseConnection();
		} catch (SQLException e) {
			// TODO: handle exception
			try {
				con.rollback();
				releaseConnection();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
			transfered = false;
		}
		return transfered;
	}

	@Override
	public boolean deleteAccount(long mobile) {
		// TODO Auto-generated method stub

		boolean deleted = false;
		try {
			makeConnection();
			con.setAutoCommit(false);
			pst = con.prepareStatement("delete from Accounts where mobileno = ?");
			pst.setLong(1, mobile);
			pst.executeUpdate();
			deleted = true;
			con.commit();
			releaseConnection();
		} catch (SQLException e) {
			// TODO: handle exception
			try {
				con.rollback();
				releaseConnection();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
			deleted = false;
		}
		return deleted;
	}

	@Override
	public boolean transferMoney(Account a1, Account a2) {
		// TODO Auto-generated method stub
		boolean transfered = false;
		try {
			makeConnection();
			con.setAutoCommit(false);
			pst = con.prepareStatement("update accounts set balance =? where acno=?");
			pst.setDouble(1, a1.getBalance());
			pst.setInt(2, a1.getAccountNo());
			int u1 = pst.executeUpdate();

			pst = con.prepareStatement("update accounts set balance =? where acno=?");
			pst.setDouble(1, a2.getBalance());
			pst.setInt(2, a2.getAccountNo());
			int u2 = pst.executeUpdate();
			System.out.println("transfer successful");
			System.out.println("Accounts Updated in database." + u2);
			walletAccounts.put(a1.getMobileNo(), a1);
			walletAccounts.put(a2.getMobileNo(), a2);
			transfered = true;
			con.commit();
			releaseConnection();
		} catch (SQLException e) {
			// TODO: handle exception
			try {
				con.rollback();
				releaseConnection();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
			transfered = false;
		}
		return transfered;
	}

	@Override

	public boolean updateAccountDetails(Account ac) {
		boolean stat = false;
		if (ac == null)
		{
			System.out.println("No Record Found.");
			System.exit(0);
		}
		else
		{
			try {
				makeConnection();
				con.setAutoCommit(false);
				pst = con.prepareStatement("update account set cname =? where acno=?");
				pst.setString(1, ac.getCustomerName());
				pst.setInt(2, ac.getAccountNo());
				pst.executeUpdate();
				stat = true;
				con.commit();
				releaseConnection();
			}
			catch (Exception e)
			{
				try {
					con.rollback();
					releaseConnection();
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				e.printStackTrace();
				stat = false;
			}
		}
		return stat;
	}
}
