package com.cg.app;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.model.Employee;
import com.cg.model.SBUDetails;

public class Main 
{
	public static void main(String[] args)
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		Employee emp = context.getBean(Employee.class);
		System.out.println("Employee Details are : "+emp.toString());
		
		SBUDetails su = context.getBean(SBUDetails.class);
		System.out.println("SBU Details are : "+su.toString());
	}

}
