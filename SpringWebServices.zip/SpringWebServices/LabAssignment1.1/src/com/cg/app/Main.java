package com.cg.app;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.model.Employee;

public class Main 
{
	public static void main(String[] args)
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		Employee emp = context.getBean(Employee.class);
		System.out.println("The Employee Details are : ");
		System.out.println("-----------------------------");
		System.out.println("Employee Id : "+emp.getEmpID());
		System.out.println("Employee Name : "+emp.getEmpname());
		System.out.println("Employee Salary : "+emp.getSalary());
		System.out.println("Business Unit : "+emp.getBusinessUnit());
		System.out.println("Age of Employee is : "+emp.getAge());
	}

}
