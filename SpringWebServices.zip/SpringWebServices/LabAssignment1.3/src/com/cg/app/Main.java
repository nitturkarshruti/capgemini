package com.cg.app;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.model.Employee;
import com.cg.model.SBUDetails;

public class Main 
{
	public static void main(String[] args)
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		
		SBUDetails su = context.getBean(SBUDetails.class);
		System.out.println("SBU Details are : "+su.toString());
		
		for(Employee e : su.getEmployee())
		{
			System.out.println(e);
		}
	}

}
