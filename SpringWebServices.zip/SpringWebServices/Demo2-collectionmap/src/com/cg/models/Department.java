package com.cg.models;

import java.util.List;
import java.util.Map;

public class Department {

	private String name;
	private Map<String,String> locations;
	
	private List<Employee> employees;
	
	public List<Employee> getEmployees() {
		return employees;
	}
	public void setEmployees(List<Employee> employees) {
		this.employees = employees;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Map<String, String> getLocations() {
		return locations;
	}
	public void setLocations(Map<String, String> locations) {
		this.locations = locations;
	}
	
	
}