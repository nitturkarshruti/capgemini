package com.cg.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.models.Department;
import com.cg.models.Employee;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		Employee e=context.getBean(Employee.class);
		System.out.println(e.getFirstname());
		System.out.println(e.getDepartment().getLocation());
		Department d1=context.getBean(Department.class);
		
		System.out.println("e.department: "+e.getDepartment());
		System.out.println("d1:"+d1);
		
		System.out.println("Shutdown the spring IOC container");
		((AbstractApplicationContext) context).close();

	}

}
