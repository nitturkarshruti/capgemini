package com.cg.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.models.Employee;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		Employee e=context.getBean(Employee.class);
		
		System.out.println(e.getFirstname());
		System.out.println(e.getDepartment().getLocation());
		System.out.println(e.getDob());
		
		System.out.println("Shutdown the spring IOC container");
		((AbstractApplicationContext) context).close();

	}

}
