package com.cg.models;

import java.util.Date;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class Employee {
	
	private String firstname;
	private String lastname;
	private Department department;
	private Date dob;
	
	@PostConstruct
	public void init() {
		System.out.println("after object creation but"+ " before its invoked using getBean");
	}
	
	@PreDestroy
	public void destroy() {
	System.out.println("Melodrama at Destroy!");
}
	
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public Department getDepartment() {
		return department;
	}
	public void setDepartment(Department department) {
		this.department = department;
	}
	
	
	

}
