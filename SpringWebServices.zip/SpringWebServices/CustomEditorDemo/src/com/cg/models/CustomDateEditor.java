package com.cg.models;

import java.beans.PropertyEditorSupport;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CustomDateEditor extends PropertyEditorSupport {
	
	private Date value;  //Date Type variable
	DateFormat df=new SimpleDateFormat("dd-MM-yyyy");
	@Override
	public String getAsText() {
		// TODO Auto-generated method stub
	
		return df.format(getValue());
	}

	@Override
	public void setAsText(String text) throws IllegalArgumentException {
		// TODO Auto-generated method stub
		try {
			setValue(df.parse(text));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new  IllegalArgumentException("Invalid date syntax, use dd-MM-yyyy");
		}
	}

}
